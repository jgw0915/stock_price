import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.BorderLayout;

public class BorderLayoutExample {
    public static void main(String[] args) {
        // Create a JFrame
        JFrame frame = new JFrame("BorderLayout Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // Create buttons
        JButton button1 = new JButton("North");
        JButton button2 = new JButton("South");
        JButton button3 = new JButton("East");
        JButton button4 = new JButton("West");
        JButton button5 = new JButton("Center");

        // Create a JPanel with BorderLayout
        frame.setLayout(new BorderLayout());

        // Add buttons to the panel with specified regions
        // frame.add(button1, BorderLayout.NORTH);
        // frame.add(button2, BorderLayout.NORTH);
        frame.add(button3, BorderLayout.EAST);
        frame.add(button4, BorderLayout.WEST);
        // frame.add(button5, BorderLayout.CENTER);

        // Set the frame visibility
        frame.setVisible(true);
    }
}