package com.example.stock_price.Model;

public enum Stock_State {
    UP,DOWN,FLAT
}
