package com.example.stock_price;
public class StockPriceApplication {

    public static void main(String[] args) {

    }

}
