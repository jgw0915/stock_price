package com.example.stock_price;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockPriceApplicationTests {

    @Test
    void contextLoads() {
    }

}
